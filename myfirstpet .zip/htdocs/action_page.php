<html>
<body>

<?php

include "database.php";
include "forum_posts.php";
?>

<h1>My First Pet</h1>


<h2>Action Page</h2>

</body>
</html>