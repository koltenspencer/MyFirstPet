<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
background-color: coral;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: SlateBlue;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>

<body>
<h1>My First Pet</h1> 
<div class="topnav">
<P><a href="view.php">Adoptable Animals<a></P>
<P><a href="Products.php">Products<a></P>
<p><a href="main_forum.php">Forums<a></p>
<P><a href="login_form.php">Login to your account<a></P>
<P><a href="add_new_user.php">Don't have an account? Create one here<a></P>
</div>

<p>
<img src="MyFirstPetLogo.jpg" alt="My First Pet Logo" class="center"
width="850"
height="650"
>
<img src="Duke.jpg" alt="Duke" class="center">
&quot;
Duke, 2 Years Old
&quot;
<img src="Mocha.jpg" alt="Mocha" class="center">
&quot;
Mocha, 2 Years Old
&quot;
<img src="Wilburt.jpg" alt="Wilburt" class="center">
&quot;
Wilburt, 8 Months Old
&quot;
</p>

<p>

</p>

<p>

</p>



</body>

</html>




